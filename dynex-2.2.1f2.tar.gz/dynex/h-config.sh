#!/usr/bin/env bash
# This code is included in /hive/bin/custom function

CUSTOM_DIR=$(dirname "$BASH_SOURCE")

. $CUSTOM_DIR/h-manifest.conf

[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1
[[ -z $CUSTOM_URL ]] && echo -e "${YELLOW}CUSTOM_URL is empty${NOCOLOR}" && return 2

[[ ! $CUSTOM_URL =~ (.*):([0-9]+) ]] && echo -e "${YELLOW}CUSTOM_URL is incorrect${NOCOLOR}" && return 3
HOST=${BASH_REMATCH[1]}
PORT=${BASH_REMATCH[2]}

conf=""
conf+="WAL=\"$CUSTOM_TEMPLATE\""$'\n'
conf+="HOST=\"$HOST\""$'\n'
conf+="PORT=\"$PORT\""$'\n'
conf+="PASS=\"$CUSTOM_PASS\""$'\n'
conf+="EXTRA=\"$CUSTOM_USER_CONFIG\""$'\n'

echo "$conf" > $CUSTOM_CONFIG_FILENAME
