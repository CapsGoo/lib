#!/usr/bin/env bash

	CUSTOM_DIR=$(dirname "$BASH_SOURCE")

	source $CUSTOM_DIR/h-manifest.conf
	source $CUSTOM_CONFIG_FILENAME

	algo="cn"

	khs=0
	stats=0
	ac=0
	rj=0

	hash_arr=()

	now=$(( $(date +%s) - 60 ))
	if [[ -f $CUSTOM_LOG_BASENAME.log && `stat -c %Y $CUSTOM_LOG_BASENAME.log` -gt $now ]]; then
		#[INFO] HASHRATE: 55 [12895]
		#[STRATUM] SHARE ACCEPTED BY POOL (8/0)
		readarray -t lines < <(tail -10 $CUSTOM_LOG_BASENAME.log)
		for((i=${#lines}-1; i>=0; i--)); do
			[[ "${lines[i]}" =~ HASHRATE:\ ([0-9]+) ]] && khs=`echo "${BASH_REMATCH[1]}" | awk '{print $1/1000}'` && hash_arr=(${BASH_REMATCH[1]}) && break
		done
		for((i=${#lines}-1; i>=0; i--)); do
			[[ "${lines[i]}" =~ POOL\ \(([0-9]+)\/([0-9]+)\) ]] && ac="${BASH_REMATCH[1]}" && rj="${BASH_REMATCH[2]}" && break
		done
	else
		echo "No log $CUSTOM_LOG_BASENAME.log"
	fi

	hash_json=`printf '%s\n' "${hash_arr[@]}" | jq -cs '.'`

	uptime=$(( `date +%s` - `stat -c %Y $CUSTOM_CONFIG_FILENAME` ))

	stats=$(jq -n --arg ac "$ac" --arg rj "$rj" --arg algo "$algo" --argjson hs "$hash_json" --arg uptime "$uptime" --arg ver "$CUSTOM_VERSION" \
		'{hs_units: "hs", $hs, $algo, $ver, $uptime, ar:[$ac|tonumber,$rj|tonumber]}')

	#echo $khs
	#echo $stats
