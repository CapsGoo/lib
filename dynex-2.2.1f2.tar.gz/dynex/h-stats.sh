#!/usr/bin/env bash

	CUSTOM_DIR=$(dirname "$BASH_SOURCE")

	#source $CUSTOM_DIR/h-manifest.conf
	#source $CUSTOM_CONFIG_FILENAME

	STATS=$CUSTOM_DIR/stats.json

	algo="cn"

	khs=0
	stats=0
	uptime=0
	ac=0
	rj=0

	hash_arr=()

	now=$(date +%s)
	upd=$(stat -c %Y $STATS 2>/dev/null)
	if (( $? == 0 && upd + 60 > now )); then
		readarray -t arr < <(jq -r '.ver, .hr, .ac, .rj, .uptime' $STATS)
		ver=${arr[0]}
		hs=${arr[1]}
		ac=${arr[2]}
		rj=${arr[3]}
		uptime=${arr[4]}
		hash_arr=($hs)
		khs=$( echo "$hs" | awk '{ printf $1/1000}')
	else
		echo "No stats.json"
	fi

	hash_json=`printf '%s\n' "${hash_arr[@]}" | jq -cs '.'`

	stats=$(jq -n --arg ac "$ac" --arg rj "$rj" --arg algo "$algo" --argjson hs "$hash_json" --arg uptime "$uptime" --arg ver "$ver" \
		'{hs_units: "hs", $hs, $algo, $ver, $uptime, ar:[$ac|tonumber,$rj|tonumber]}')

	#echo $khs
	#echo $stats
